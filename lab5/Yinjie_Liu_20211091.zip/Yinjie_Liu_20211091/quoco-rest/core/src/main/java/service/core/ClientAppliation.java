package service.core;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ClientAppliation {
    private ClientInfo clientInfo;
    private static int id;
    private ArrayList<Quotation> quotations = new ArrayList();

    public ClientAppliation(ClientInfo clientInfo, int id, ArrayList<Quotation> quotations) {
        this.clientInfo = clientInfo;
        this.id = id;
        this.quotations = quotations;
    }

    public ClientAppliation(){}

    public ClientInfo getClientInfo() {
        return clientInfo;
    }

    public int getId() {
        return id;
    }

    public ArrayList<Quotation> getQuotations() {
        return quotations;
    }

    public void setClientInfo(ClientInfo clientInfo) {
        this.clientInfo = clientInfo;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setQuotations(ArrayList<Quotation> quotations) {
        this.quotations = quotations;
    }
}
