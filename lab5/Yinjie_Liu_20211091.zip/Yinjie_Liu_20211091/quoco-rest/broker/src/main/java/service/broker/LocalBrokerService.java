package service.broker;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.*;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import service.core.ClientAppliation;
import service.core.ClientInfo;
import service.core.Quotation;


/**
 * Implementation of the broker service that uses the Service Registry.
 * 
 * @author Rem
 *
 */
@RestController
public class LocalBrokerService{

	private ClientAppliation application = new ClientAppliation();
	private static int SEED = 0;
	private Map<Integer, ClientAppliation> map1 = new HashMap<>();
	private ArrayList<ClientAppliation> array1 = new ArrayList();
	private  static  String[] urls = {"http://localhost:8080/quotations","http://localhost:8081/quotations","http://localhost:8082/quotations"};



	@RequestMapping(value="/application",method= RequestMethod.POST)
	public ClientAppliation createApplication(@RequestBody ClientInfo info) throws URISyntaxException {
		getQuotations(info);
		ClientAppliation appliation = map1.get(SEED);

		return appliation;
	}



	public ArrayList<Quotation> getQuotations(ClientInfo info) {


		ArrayList<Quotation> quotations = new ArrayList<>();

		for (String url : urls) {
			RestTemplate restTemplate = new RestTemplate();
			HttpEntity<ClientInfo> request = new HttpEntity<>(info);
			Quotation quotation = restTemplate.postForObject(url, request, Quotation.class);
			quotations.add(quotation);
		}
		ClientAppliation appliation = new ClientAppliation(info,++SEED,quotations);
		map1.put(application.getId(), appliation);

		return appliation.getQuotations() ;
	}

	@RequestMapping(value="/application/{id}",method=RequestMethod.GET)
	public ClientAppliation getResource(@PathVariable("id") Integer id) {
		ClientAppliation appliation = map1.get(id);
		if (appliation == null) throw new NoSuchQuotationException();
		return appliation;
	}

	@ResponseStatus(value = HttpStatus.NOT_FOUND)
	public class NoSuchQuotationException extends RuntimeException {
		static final long serialVersionUID = -6516152229878843037L;
	}

	@RequestMapping(value="/application",method=RequestMethod.GET)
	public ArrayList<ClientAppliation> getResource() {
		if (array1 == null) throw new NoSuchQuotationException2();
		return array1;
	}

	@ResponseStatus(value = HttpStatus.NOT_FOUND)
	public class NoSuchQuotationException2 extends RuntimeException {
		static final long serialVersionUID = -6516152229878843037L;
	}
}
