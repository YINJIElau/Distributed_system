package service.message;


import service.core.ClientInfo;
import service.core.Quotation;

import java.util.LinkedList;
import java.util.List;
import java.io.Serializable;


public class ClientApplicationMessage implements Serializable {
    public ClientInfo clientInfo;
    public List<Quotation> quotations = new LinkedList<Quotation>();
    public long id;
}
