package service.core;

import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.List;

/**
 * Interface for defining the behaviours of the broker service
 * @author Rem
 *
 */
public interface BrokerService{
	public List<Quotation> getQuotations(ClientInfo info) throws RemoteException, NotBoundException;
}
