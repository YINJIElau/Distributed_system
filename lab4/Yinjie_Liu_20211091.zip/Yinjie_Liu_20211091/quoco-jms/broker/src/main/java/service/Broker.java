package service;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.text.NumberFormat;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;


//import service.core.BrokerService;
import service.core.BrokerService;
import service.core.ClientInfo;
import service.core.Constants;

import javax.jms.*;
import javax.jms.Queue;

import org.apache.activemq.ActiveMQConnectionFactory;
import service.core.Quotation;
import service.message.ClientApplicationMessage;
import service.message.QuotationRequestMessage;
import service.message.QuotationResponseMessage;

public class Broker{


    private static long SEED_ID = 0;
    private static Map<Long, ClientInfo> cache = new HashMap<Long, ClientInfo>();
    private static List<ClientApplicationMessage> response = new LinkedList<ClientApplicationMessage>();
    public static  ConcurrentHashMap<Long, List<Quotation>> idquotations = new ConcurrentHashMap<Long, List<Quotation>>();



    /**
     * This is the starting point for the application. Here, we must
     * get a reference to the Broker Service and then invoke the
     * getQuotations() method on that service.
     * <p>
     * Finally, you should print out all quotations returned
     * by the service.
     *
     * @param args
     */
    public static void main(String[] args) throws JMSException {

        try {
            String host = args.length == 0 ? "localhost" : args[0];
            ConnectionFactory factory =
                    new ActiveMQConnectionFactory("failover://tcp://" + host + ":61616");
            Connection connection = factory.createConnection();
            connection.setClientID("receiveinfo");
            Session session = connection.createSession(false, Session.CLIENT_ACKNOWLEDGE);


            connection.start();
            new Thread(new ClientRequest(session)).start();
            new Thread(new QuotationRequest(session)).start();
        } catch (JMSException e) {
            e.printStackTrace();
        }

    }
    public static class ClientRequest implements Runnable {

        Session session;

        public ClientRequest(Session session) {
            this.session = session;
        }

        @Override
        public void run() {
            try {
                Queue queue2 = session.createQueue("QUOTATIONS");
                Topic topic = session.createTopic("APPLICATIONS");

                MessageConsumer consumer = session.createConsumer(queue2);
                MessageProducer producer = session.createProducer(topic);
                while (true) {
                    Message message = consumer.receive();
                    if (message instanceof ObjectMessage) {
                        Object content = ((ObjectMessage) message).getObject();
                        QuotationRequestMessage quotation = (QuotationRequestMessage) content;


                        cache.put(quotation.id, quotation.info);
                        if (content instanceof QuotationRequestMessage) {
                            message.acknowledge();
                            producer.send(message);
                            System.out.println("Broker sends request to service");
                        }
                    }
                }
            } catch (JMSException e) {
                e.printStackTrace();
            }
        }
    }


    public static class QuotationRequest implements Runnable {

        Session session;
        public QuotationRequest(Session session) {
            this.session = session;
        }
        @Override
        public void run() {
            try {
                Queue queue1 = session.createQueue("PRODUCEQUOTATIONS");
                MessageConsumer consumer1 = session.createConsumer(queue1);
                new Thread(new CreateQuotationResponse(session)).start();
                while(true) {
                    System.out.println("Broker get quotation");
                    Message message = consumer1.receive();
                    if (message instanceof ObjectMessage) {
                        Object content = ((ObjectMessage) message).getObject();
                        if (content instanceof QuotationResponseMessage) {
                            QuotationResponseMessage quotation = (QuotationResponseMessage) content;
                            message.acknowledge();


                            if(idquotations.containsKey(quotation.id)) {
                                idquotations.get(quotation.id).add(quotation.quotation);
                            } else {
                                List<Quotation> q = new ArrayList<Quotation>();
                                q.add(quotation.quotation);
                                idquotations.put(quotation.id, q);
                                System.out.println("Broker id quotation");
                            }
                        }
                    }
                }
            } catch(JMSException e){
                e.printStackTrace();
            }
        }

    }


    public static class CreateQuotationResponse implements Runnable {

        Session session;

        public CreateQuotationResponse(Session session) {
            this.session = session;
        }

        @Override
        public void run() {
            try {
                Thread.sleep(7777);
                boolean i = true;
                while (i) {
                    System.out.println("This is here");
                    if (idquotations != null && !idquotations.isEmpty()) {
                        for (Map.Entry<Long, ClientInfo> client : cache.entrySet()) {
                            for (Map.Entry<Long, List<Quotation>> quotations : idquotations.entrySet()) {
                                if (client.getKey().equals(quotations.getKey())) {
                                    ClientApplicationMessage onequotation = new ClientApplicationMessage();


                                    onequotation.clientInfo = client.getValue();
                                    onequotation.quotations = quotations.getValue();
                                    response.add(onequotation);
                                    System.out.println("Broker response");
                                }
                            }
                        }
                        i = false;
                    }
                }
                Queue sendquotationqueue = session.createQueue("SENDQUOTATIONS");
                MessageProducer producer = session.createProducer(sendquotationqueue);
                System.out.println("right here");
                for (ClientApplicationMessage clientresponse : response) {
                    Message response = session.createObjectMessage(clientresponse);
                    producer.send(response);
                    System.out.println("broker sends quotation to client");
                }
            } catch (JMSException | InterruptedException e) {
                e.printStackTrace();
            }
        }



    }


}