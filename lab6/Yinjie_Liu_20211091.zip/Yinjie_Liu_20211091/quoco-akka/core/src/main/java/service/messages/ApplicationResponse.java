package service.messages;

import service.core.ClientInfo;
import service.core.Quotation;

import java.util.LinkedList;
import java.util.List;

public class ApplicationResponse implements MySerializable{

    private ClientInfo info;
    private List<Quotation> quotations;

    public ApplicationResponse() {}

    public ApplicationResponse(ClientInfo info) {
        this.info = info;
        this.quotations = new LinkedList<>();
    }

    public ClientInfo getInfo() {
        return info;
    }

    public void setInfo(ClientInfo info) {
        this.info = info;
    }

    public List<Quotation> getQuotations() {
        return quotations;
    }

    public void setQuotations(List<Quotation> quotations) {
        this.quotations = quotations;
    }
}
