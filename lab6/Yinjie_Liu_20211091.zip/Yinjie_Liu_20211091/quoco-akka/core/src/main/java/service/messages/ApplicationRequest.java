package service.messages;

import service.core.ClientInfo;

public class ApplicationRequest implements MySerializable {

    private ClientInfo info;

    public ApplicationRequest() {}

    public ApplicationRequest(ClientInfo info) {
        this.info = info;
    }

    public ClientInfo getInfo() {
        return info;
    }

    public void setInfo(ClientInfo info) {
        this.info = info;
    }
}
