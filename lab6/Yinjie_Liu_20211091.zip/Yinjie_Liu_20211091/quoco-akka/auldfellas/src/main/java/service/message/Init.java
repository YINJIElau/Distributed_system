package service.message;

import service.core.QuotationService;

public class Init {

    private QuotationService serivice;

    public Init(QuotationService quotationService) {
        this.serivice = quotationService;
    }

    public QuotationService getQuotationService() {
        return serivice;
    }

    public void setQuotationService(QuotationService quotationService) {
        this.serivice = quotationService;
    }

}
