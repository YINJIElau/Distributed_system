package service.messages;

public class RequestDeadline {

    private int id;
    public RequestDeadline(int id) {
        this.id = id;
    }
    public int getId() {
        return id;
    }

}
