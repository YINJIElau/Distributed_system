package service.actor;

import akka.actor.AbstractActor;
import akka.actor.ActorRef;
import scala.concurrent.duration.Duration;
import service.messages.*;

import java.util.*;
import java.util.concurrent.TimeUnit;

public class Broker extends AbstractActor {

    private static int SEED_ID = 0;
    private List<ActorRef> actorRefs;
    private Map<Integer, ActorRef> clientRefs;
    private Map<Integer, ApplicationResponse> cache;
    // ApplicationResponse includes info and quotations

    public Broker() {
        this.actorRefs = new LinkedList<ActorRef>();
        this.clientRefs = new HashMap<>();
        this.cache = new HashMap<>();
    }

    @Override
    public Receive createReceive() {
        return receiveBuilder()
                .match(String.class,
                        msg -> {
                            if (!msg.equals("register")) return;
                            actorRefs.add(getSender());  // handle incoming registration request message
                        })
                .match(ApplicationRequest.class,
                        msg -> {
                            for(ActorRef ref : actorRefs) {
                                ref.tell(new QuotationRequest(SEED_ID, msg.getInfo()), getSelf());
                            }

                            clientRefs.put(SEED_ID, getSender());
                            cache.put(SEED_ID, new ApplicationResponse(msg.getInfo()));
                            getContext().system().scheduler().scheduleOnce(
                                    Duration.create(10, TimeUnit.SECONDS),
                                    getSelf(), new RequestDeadline(SEED_ID++),
                                    getContext().dispatcher(), null);
                        })
                .match(QuotationResponse.class,
                        msg -> {
                            int id = msg.getId();
                            cache.get(id).getQuotations().add(msg.getQuotation());
                        })
                .match(RequestDeadline.class,
                        msg -> {
                            int id = msg.getId();
                            System.out.println(msg.getId());
                            clientRefs.get(id).tell(cache.get(msg.getId()), getSelf());
                        })
                .build();
    }
}
