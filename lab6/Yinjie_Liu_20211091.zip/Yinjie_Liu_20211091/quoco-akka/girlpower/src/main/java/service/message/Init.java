package service.message;

import service.core.QuotationService;

public class Init {

    private QuotationService quotationService;

    public Init(QuotationService quotationService) {
        this.quotationService = quotationService;
    }

    public QuotationService getQuotationService() {
        return quotationService;
    }

    public void setQuotationService(QuotationService quotationService) {
        this.quotationService = quotationService;
    }

}
