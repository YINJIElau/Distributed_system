package service.core;
import com.sun.net.httpserver.HttpContext;
import com.sun.net.httpserver.HttpServer;
import service.core.*;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.*;
import javax.jws.soap.SOAPBinding.Style;
import javax.jws.soap.SOAPBinding.Use;
import javax.xml.ws.Endpoint;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.text.NumberFormat;
import javax.xml.ws.Service;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.concurrent.Executors;
import javax.xml.namespace.QName;
import java.net.URL;

import javax.xml.namespace.QName;


@WebService
@SOAPBinding(style = Style.DOCUMENT, use = Use.LITERAL)
public class Broker {

	public static HashSet<String> urls = new HashSet<String>();
    public static void main(String[] args) {
		try {
			Endpoint endpoint = Endpoint.create(new Broker());
			HttpServer server = HttpServer.create(new InetSocketAddress(9000), 5);
			server.setExecutor(Executors.newFixedThreadPool(5));
			HttpContext context = server.createContext("/getQuotations");
			endpoint.publish(context);
			server.start();

			JmDNS jmDNS = JmDNS.create(InetAddress.getLocalHost());
			jmDNS.addServiceListener("_http._tcp.local.", new WSDLServiceListener());
		} catch (Exception e) {
			e.printStackTrace();
		}

    }

	public static class WSDLServiceListener implements ServiceListener {
		@Override
		public void serviceAdded(ServiceEvent event) {
		}

		@Override
		public void serviceRemoved(ServiceEvent event) {
		}

		@Override
		public void serviceResolved(ServiceEvent event) {
			String path = event.getInfo().getPropertyString("path");
			if (path != null) {
				String url = event.getInfo().getURLs()[0];
				urls.add(url);
			}
		}
	}

	@WebMethod
	public LinkedList<Quotation> getQuotations(ClientInfo info) {
		LinkedList<Quotation> quotations = new LinkedList<Quotation>();
		try {
			for (String url : urls) {
				URL wsdlUrl = new URL(url);
				QName serviceName =
						new QName("http://core.service/", "QuoterService");
				Service service = Service.create(wsdlUrl, serviceName);
				QName portName = new QName("http://core.service/", "QuoterPort");
				QuoterService quotationService =
						service.getPort(portName, QuoterService.class);
				System.out.println("This is broker!");

				Quotation quotation = quotationService.generateQuotation(info);
				quotations.add(quotation);
			}
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
		return quotations;
	}

}