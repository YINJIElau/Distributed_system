package service.core;

import javax.jws.WebMethod;
import javax.jws.WebService;

import service.core.ClientInfo;
import service.core.Quotation;

@WebService
public interface QuoterService {
    @WebMethod
    Quotation generateQuotation(ClientInfo info);
}