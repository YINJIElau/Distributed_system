package service.core;

import javax.jws.WebMethod;
import javax.jws.WebService;
import service.core.ClientInfo;
import service.core.Quotation;

import java.util.LinkedList;


@WebService
public interface BrokerService{
	@WebMethod
	LinkedList<Quotation> getQuotations(ClientInfo info);




}