package broker;

import java.util.LinkedList;
import java.util.List;

import core.BrokerService;
import core.ClientInfo;
import core.Quotation;
import core.QuotationService;
import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
// import service.registry.ServiceRegistry;

/**
 * Implementation of the broker service that uses the Service Registry.
 * 
 * @author Rem
 *
 */
public class LocalBrokerService implements BrokerService {
	public List<Quotation> getQuotations(ClientInfo info) throws RemoteException, NotBoundException{

		
		List<Quotation> quotations = new LinkedList<Quotation>();
		

			Registry registry = LocateRegistry.getRegistry();

			for (String name : registry.list()) {
				if (name.startsWith("qs-")) {
					QuotationService service = (QuotationService)registry.lookup(name);
					quotations.add(service.generateQuotation(info));
				}
			}



		

		return quotations;
	}
}
