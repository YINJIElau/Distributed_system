import java.rmi.registry.Registry; 
import java.rmi.registry.LocateRegistry; 
import java.rmi.server.UnicastRemoteObject; 
import core.Constants;
import core.QuotationService;
import broker.LocalBrokerService;
import core.BrokerService;
import core.Quotation;
import java.text.NumberFormat;
import core.ClientInfo;
import org.junit.*; 
import static org.junit.Assert.assertNotNull; 
public class BrokerUnitTest { 
private static Registry registry;
 @BeforeClass 
 public static void setup() { 
// QuotationService afqService = new AFQService();
 BrokerService localBrokerService = new LocalBrokerService();  
 try { 
 registry = LocateRegistry.createRegistry(1099);
 BrokerService brokerservice = (BrokerService)  
 UnicastRemoteObject.exportObject(localBrokerService,0);
 registry.bind(Constants.BROKER_SERVICE, brokerservice);
 } catch (Exception e) { 
 System.out.println("Trouble: " + e); 
 } 
 }

// public static void displayQuotation(Quotation quotation) {
//  System.out.println(
//          "| Company: " + String.format("%1$-26s", quotation.company) +
//                  " | Reference: " + String.format("%1$-24s", quotation.reference) +
//                  " | Price: " + String.format("%1$-28s", NumberFormat.getCurrencyInstance().format(quotation.price))+" |");
//  System.out.println("|=================================================================================================================|");
// }



 @Test 
 public void connectionTest() throws Exception { 
 // QuotationService service = (QuotationService)
 BrokerService brokerservice = (BrokerService) 
 registry.lookup(Constants.BROKER_SERVICE); 
 assertNotNull(brokerservice);
 ClientInfo clientInfo = new ClientInfo("Niki Collier", ClientInfo.FEMALE, 43, 0, 5, "PQR254/1");
 System.out.println(brokerservice.getQuotations(clientInfo).getClass().toString());
// for(Quotation quotation : brokerservice.getQuotations(clientInfo)) {
//   displayQuotation(quotation);
// }



// ClientInfo clieninfo = new ClientInfo("Yinjie Liu", ClientInfo.MALE, 43, 0, 5, "20211091");
// System.out.println(brokerservice.getQuotations(clieninfo).getClass());
 
 } 
}